package com.springboot.web;

import com.springboot.model.*;
import com.springboot.Dao.*;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import static com.springboot.Dao.Dao.*;

@Controller
public class UserController {
    //登录界面响应
    @CrossOrigin
    @RequestMapping(value = "/login")
    public @ResponseBody
    String login(@RequestParam("username") String username, @RequestParam("password") String password){
        System.out.println(username+" "+password);
        try
        {
            if(userlogin(username, password)) return "true";
            else return "false";
        }
        catch (Exception e)
        {
            e.printStackTrace();
            return "false";
        }
    }

    //注册1界面响应
    @CrossOrigin
    @RequestMapping(value = "/register1")
    public @ResponseBody
    String register1(@RequestParam("phone") String phone){
        System.out.println(phone);
        return "true";
    }

    //注册2界面响应
    @CrossOrigin
    @RequestMapping(value = "/register2")
    public @ResponseBody
    String register2(@RequestParam("username") String username, @RequestParam("password") String password){
        System.out.println(username+" "+password);
        try
        {
            if(resister(username,password)) return "true";
            else return "false";
        }
        catch (Exception e)
        {
            e.printStackTrace();
            return "false";
        }
    }

    //修改密码界面响应
    @CrossOrigin
    @RequestMapping(value = "/alter")
    public @ResponseBody
    String alter(@RequestParam("username") String username, @RequestParam("oldpassword") String oldpassword,
                 @RequestParam("password") String password)
    {
        System.out.println(username+" "+oldpassword+" "+"请求修改密码为"+password);
        try
        {
            if(changepassword(username,oldpassword,password)) return "true";
            else return "false";
        }
        catch (Exception e)
        {
            e.printStackTrace();
            return "false";
        }
    }

    //系统界面生成试卷响应
    @CrossOrigin
    @RequestMapping(value = "/creatpaper")
    public @ResponseBody
    String creatpaper(@RequestParam("num") String num,@RequestParam("paper_type") String paper_type){
        Dao dao = new Dao();
        String str = "[";
        for (int i=0;i<Integer.parseInt(num);i++)
        {
            Question question = dao.CreateQuestion(paper_type);
            if(i==Integer.parseInt(num)-1)
                  {
                    str+=question.toString();
            }
            else
            {
                str+=question.toString()+",";
            }
        }
        str+="]";
        return str;
    }
}
