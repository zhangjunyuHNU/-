package com.springboot.model;

/**
 * 为试卷的数据库实体类，包含题目类型、内容、答案
 */
public class Question {
    private String q_type;
    private String q_content;
    private Integer answer1;
    private Integer answer2;
    private Integer answer3;
    private Integer answer4;
    private Integer rd;
    public Question() {
    }

    public Question(String m_type) {
        this.q_type = m_type;
    }

    public String getQ_type() {
        return q_type;
    }
    public void setQ_type(String q_type) {
        this.q_type = q_type;
    }

    public String getQ_content() {
        return q_content;
    }
    public void setQ_content(String q_content) {
        this.q_content = q_content;
    }

    public Integer get_rd(){ return rd; }
    public void set_rd(Integer rd) { this.rd=rd; }

    public Integer get_answer1() { return answer1;}
    public void set_answer1(Integer answer1) { this.answer1=answer1;}

    public Integer get_answer2() { return answer2;}
    public void set_answer2(Integer answer2) { this.answer2=answer2;}

    public Integer get_answer3() { return answer3;}
    public void set_answer3(Integer answer3) { this.answer3=answer3;}

    public Integer get_answer4() { return answer4;}
    public void set_answer4(Integer answer4) { this.answer4=answer4;}

    @Override
    public String toString() {
        return "{" +
                "\"q_content\":\"" + q_content + '\"' +
                ", \"answer1\":\"" + answer1 + '\"' +
                ", \"answer2\":\"" + answer2 + '\"' +
                ", \"answer3\":\"" + answer3 + '\"' +
                ", \"answer4\":\"" + answer4 + '\"' +
                ", \"rd\":\"" + rd + '\"' +
                '}';
    }
}
