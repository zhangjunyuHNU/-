package com.springboot.model;

/**
 * 为用户数据库的实体类，包含账户类型、账号、密码
 */
public class User {
    private String u_type;
    private String u_account;
    private String u_password;

    public User(String type, String account, String password) {
        this.u_type = type;
        this.u_account = account;
        this.u_password = password;
    }

    public User() {

    }

    public String getU_type() {
        return u_type;
    }

    public void setU_type(String u_type) {
        this.u_type = u_type;
    }

    public String getU_account() {
        return u_account;
    }

    public void setU_account(String u_account) {
        this.u_account = u_account;
    }

    public String getU_password() {
        return u_password;
    }

    public void setU_password(String u_password) {
        this.u_password = u_password;
    }

    @Override
    public String toString() {
        return "User{" +
                "u_type='" + u_type + '\'' +
                ", u_account='" + u_account + '\'' +
                ", u_password='" + u_password + '\'' +
                '}';
    }
}