package com.springboot.Dao;
import com.springboot.model.*;

import java.io.*;
import java.util.*;

public class Dao {
    /**
     *
     * @param Users
     * @return 已赋值的Users
     * 形成Users数据表单
     */
    public static  List<User> SetUsers(List<User> Users)
    {
        Users.add(new User("小学","张三1","123"));
        Users.add(new User("小学","张三2","123"));
        Users.add(new User("小学","张三3","123"));
        Users.add(new User("初中","李四1","123"));
        Users.add(new User("初中","李四2","123"));
        Users.add(new User("初中","李四3","123"));
        Users.add(new User("高中","王五1","123"));
        Users.add(new User("高中","王五2","123"));
        Users.add(new User("高中","王五3","123"));
        return Users;
    }

    /**
     * 根据类型自动创建题目
     * @param type
     * @return 返回已创建好的题目 Question
     */
    public static Question CreateQuestion(String type)
    {
        Question Q = new Question(type);//获得题目类型
        Random random = new Random();//生成随机数
        String content = "";
        int HandleNum = random.nextInt(5)+1;//生成操作数的数量(1-5)
        int tag1 = random.nextInt(HandleNum);//标志生成 平方、开方 的位置
        int tag2 = random.nextInt(HandleNum);//标志生成 sin、cos、tan 的位置
        //生成相关类型的的题目
        int parentheses = 0;//用于生成括号，等于1时表示生成了左括号，等于2时表示生成了右括号
        for(int i=0;i<HandleNum;i++)
        {
            if(parentheses==1&&random.nextInt(2)==1)//生成右括号
            {
          /*      if(type.equals("高中")&&tag2==i) content = AddSign3(content,random.nextInt(3));
                content += (random.nextInt(100)+1)+ ")";
                parentheses = 2;
                if((type.equals("初中")||type.equals("高中"))&&tag1==i)
                {
                    content = AddSign2(content,random.nextInt(2));//插入初中符号
                }*/
                if(type.equals("高中")&&tag2==i)
                {
                    int randomnum1=random.nextInt(3);
                    int randomnum2;
                    if(randomnum1==2||randomnum1==1) //tan和cos
                    {
                        randomnum2=random.nextInt(3);
                    }
                    else
                    {
                        randomnum2=random.nextInt(4);
                    }
                    content = AddSign3(content,randomnum1);
                    switch (randomnum2)
                    {
                        case 0:
                        {
                            content+="30"+")";
                            break;
                        }
                        case 1:
                        {
                            content+="45"+")";
                            break;
                        }
                        case 2:
                        {
                            content+="60"+")";
                            break;
                        }
                        case 3:
                        {
                            content+="90"+")";
                            break;
                        }
                    }
                }
                else
                {
                    content += (random.nextInt(100))+ ")";
                }
                parentheses=2;
                if((type.equals("初中")||type.equals("高中"))&&tag1==i)
                {
                    content = AddSign2(content,random.nextInt(2));//插入初中符号
                }
            }
            else if(parentheses==0&&random.nextInt(2)==1)//生成左括号
            {
      /*          if(type.equals("高中")&&tag2==i)
                {
                    content = AddSign3(content,random.nextInt(3));//插入高中符号
                }
                content += "("+(random.nextInt(100)+1);//生成操作数值;*/
                if(type.equals("高中")&&tag2==i)
                {
                    content += "(";
                    int randomnum1=random.nextInt(3);
                    int randomnum2;
                    if(randomnum1==2||randomnum1==1) //tan,cos
                    {
                        randomnum2=random.nextInt(3);
                    }
                    else
                    {
                        randomnum2=random.nextInt(4);
                    }
                    content = AddSign3(content,randomnum1);
                    switch (randomnum2)
                    {
                        case 0:
                        {
                            content+="30";
                            break;
                        }
                        case 1:
                        {
                            content+="45";
                            break;
                        }
                        case 2:
                        {
                            content+="60";
                            break;
                        }
                        case 3:
                        {
                            content+="90";
                            break;
                        }
                    }
                }
                else
                {
                    content += "("+(random.nextInt(100));
                }
                parentheses = 1;//左括号标志位为1
                if((type.equals("初中")||type.equals("高中"))&&tag1==i)
                    content = AddSign2(content,random.nextInt(2));
            }
            else{
                if(type.equals("小学"))
                {
                    content += random.nextInt(100);
                }
                else if(type.equals("初中"))
                {
                    content += random.nextInt(100);
                    if(tag1==i)
                    {
                        content = AddSign2(content,random.nextInt(2));//插入初中符号
                    }
                }
                else {//高中时
               /*     if(tag2==i) content = AddSign3(content,random.nextInt(3));//插入高中符号
                    content += random.nextInt(100)+1;//插入数值
                    if(tag1==i) content = AddSign2(content,random.nextInt(2));//插入初中符号*/
                    if(tag2==i)
                    {
                        int randomnum1=random.nextInt(3);
                        int randomnum2;
                        if(randomnum1==2||randomnum1==1) //tan
                        {
                            randomnum2=random.nextInt(3);
                        }
                        else
                        {
                            randomnum2=random.nextInt(4);
                        }
                        content = AddSign3(content,randomnum1);
                        switch (randomnum2)
                        {
                            case 0:
                            {
                                content+="30";
                                break;
                            }
                            case 1:
                            {
                                content+="45";
                                break;
                            }
                            case 2:
                            {
                                content+="60";
                                break;
                            }
                            case 3:
                            {
                                content+="90";
                                break;
                            }
                        }
                        if(tag1==i)
                        {
                            content = AddSign2(content,random.nextInt(2));
                        }
                    }
                    else
                    {
                        content += random.nextInt(100);//插入数值
                        if(tag1==i) content = AddSign2(content,random.nextInt(2));
                    }
                }
            }
            content = AddSign1(content,random.nextInt(4));//插入小学符号
        }
        int len = content.length();
        content = content.substring(0,len-1);
        if(parentheses == 1) content+=")";

        //当括号内有双目运算符或者括号外有平方根号时，不去括号
        int zuokuohao=content.indexOf("(");
        int youkuohao=content.indexOf(")");
        boolean kuohao_flag=true;     //为真则去掉括号，为假则不去掉;
        if(zuokuohao!=youkuohao)
        {
            for(int i=zuokuohao+1;i<youkuohao;i++)
            {
                if(content.charAt(i)=='+'||content.charAt(i)=='-'||content.charAt(i)=='*'||content.charAt(i)=='/')
                {
                    kuohao_flag=false;
                }
                int l2=content.length();
                if(l2!=youkuohao+1)
                {
                    int youkuohaoplus=youkuohao+1;
                    if(content.charAt(i)=='-'&&content.charAt(youkuohaoplus)=='½')
                    {
                        content=content.replace('½','²');
                    }
                }

            }
            int len2=content.length();
            if(len2!=youkuohao+1)
            {
                int youkuohaoplus=youkuohao+1;
                if(content.charAt(youkuohaoplus)=='½'||content.charAt(youkuohaoplus)=='²')
                {
                    kuohao_flag=false;
                }
            }
            if(kuohao_flag==true)
            {
                content=removeCharAt(content,zuokuohao);
                content=removeCharAt(content,youkuohao-1);
            }
        }

        //增添一组括号，防止出现sin30²之类的情况，因为要保证sin的目标操作数是好计算的
        int genhao=content.indexOf("½");
        int pingfang=content.indexOf("²");
        if(genhao!=-1||pingfang!=-1)
        {
            int temp=0;
            if(genhao!=-1)
            {
                temp=genhao;
            }
            else
            {
                temp=pingfang;
            }
            if(temp>4)
            {
                if(content.charAt(temp-4)=='i'||content.charAt(temp-4)=='o'||content.charAt(temp-4)=='a')
                {
                    //除去原有的括号
                    int zuokuo=content.indexOf("(");
                    int youkuo=content.indexOf(")");
                    if(zuokuo!=youkuo)
                    {
                        int lengg=content.length();
                        if(zuokuo==0&&youkuo==lengg-1)  //两边
                        {
                            content=content.substring(1,youkuo);
                        }
                        else if(zuokuo==0&&youkuo!=lengg-1) //左括号在最左边，右括号不在最右边
                        {
                            String contentf=content.substring(1,youkuo);
                            String contents=content.substring(youkuo+1);
                            content=contentf+contents;
                        }
                        else if(zuokuo!=0&&youkuo==lengg-1) //左括号不在最左边，右括号在最右边
                        {
                            String contentf=content.substring(0,zuokuo);
                            String contents=content.substring(zuokuo+1,youkuo);
                            content=contentf+contents;
                        }
                        else            //括号在中间
                        {
                            String contentf=content.substring(0,zuokuo);
                            String contents=content.substring(zuokuo+1,youkuo);
                            String contentt=content.substring(youkuo+1);
                            content=contentf+contents+contentt;
                        }
                    }

                    //准备给sin30²之类的数增加括号
                    genhao=content.indexOf("½");
                    pingfang=content.indexOf("²");
                    temp=genhao!=-1?genhao:pingfang;
                    String content1=content.substring(0,temp-5);
                    String content2=content.substring(temp-5,temp);
                    String content3=content.substring(temp);
                    content=content1+"("+content2+")"+content3;
                }
            }
        }
        //当括号在式子两边时，去括号
        zuokuohao=content.indexOf("(");
        youkuohao=content.indexOf(")");
        len = content.length();
        if(zuokuohao==0&&youkuohao==len-1)
        {
            content=content.substring(1,youkuohao);
        }

        //小学只有一个操作数时得加一个
        if(HandleNum==1&&type.equals("小学"))
        {
            content = AddSign1(content,random.nextInt(4));
            content += random.nextInt(100);
        }
        Q.setQ_content(content+"=");
        Double result=total_calculate(content);
        Integer trueresult=result.intValue();
    /*    BigDecimal b = new BigDecimal(result);
        Double trueresult=b.setScale(3, BigDecimal.ROUND_HALF_UP).doubleValue();*/
        Integer a[]={-10,-6,-4,-3,-2,-5,11,4,7,9,10};
        int x=12,y=12,z=12;
        int temp=12;
        x=random.nextInt(11);
        while(true)
        {
            temp=random.nextInt(11);
            if(temp!=x)
            {
                y=temp;
                break;
            }
        }
        while (true)
        {
            temp=random.nextInt(11);
            if(temp!=x&&temp!=y)
            {
                z=temp;
                break;
            }
        }
        int temp2=random.nextInt(4);
        Integer wronganswer1=trueresult+a[x];
        Integer wronganswer2=trueresult+a[y];
        Integer wronganswer3=trueresult+a[z];
        Q.set_rd(temp2);
        switch (Q.get_rd())
        {
            case 0:
            {
                Q.set_answer1(trueresult);
                Q.set_answer2(wronganswer1);
                Q.set_answer3(wronganswer2);
                Q.set_answer4(wronganswer3);
            }
            case 1:
            {
                Q.set_answer1(wronganswer1);
                Q.set_answer2(trueresult);
                Q.set_answer3(wronganswer2);
                Q.set_answer4(wronganswer3);
            }
            case 2:
            {
                Q.set_answer1(wronganswer1);
                Q.set_answer2(wronganswer2);
                Q.set_answer3(trueresult);
                Q.set_answer4(wronganswer3);
            }
            case 3:
            {
                Q.set_answer1(wronganswer1);
                Q.set_answer2(wronganswer2);
                Q.set_answer3(wronganswer3);
                Q.set_answer4(trueresult);
            }
        }
        return Q;
    }

    private static String removeCharAt(String str, int i)
    {
        int len=str.length();
        if(i==len)
        {
            return str.substring(0,i);
        }
        else
        {
            return str.substring(0, i)+str.substring(i+1);
        }
    }
    /**
     * 查重函数，有相同的则返回 false ， 没有则返回 true
     * @param Q
     * @param path
     * @return true or false
     */
    public static Boolean CheckQuestions(Question Q,String path) throws Exception
    {
        path="试卷\\"+path;
        File file = new File(path);
        File[] files = file.listFiles();
        for (int i = 0; i < files.length; i++)
        {
            if (files[i].isFile())
            {
                InputStreamReader reader = new InputStreamReader(new FileInputStream(files[i]));
                BufferedReader br = new BufferedReader(reader);
                String line="";
                while ((line = br.readLine()) != null){
                    if(line.substring(line.indexOf("、")+1).equals(Q.getQ_content()))
                    {
                        return false;
                    }
                }
                br.close();
            }
        }
        return true;
    }

    /**
     * 根据sign1自动在Q_content添加 加减乘除
     * @param content
     * @param flag
     * @return 添加符号后的 Q_content
     */
    public static String AddSign1(String content,int flag)
    {
        if(flag == 0)
        {
            content += "+";
        }
        else if(flag == 1)
        {
            content += "-";
        }
        else if(flag == 2)
        {
            content += "*";
        }
        else {
            content += "/";
        }
        return content;
    }

    /**
     * 初中题目插入 平方和开方
     * @param content
     * @param flag
     * @return 已赋值的 Q_content
     */
    public static String AddSign2(String content,int flag)
    {
        if(flag==0)
        {
            content += "²";
        }
        else content += "½";
        return content;
    }

    /**
     * 高中题目插入sin、cos、tan的值
     * @param content
     * @param flag
     * @return 已插值的 Q_content
     */
    public static String AddSign3(String content,int flag)
    {
        if(flag==0)
        {
            content = content + "sin";
        }
        else if(flag==1) content = content + "cos";
        else content = content + "tan";
        return content;
    }
    public static Double total_calculate(String question)
    {
        String inner_question="";
        String end_question="";
        int zuokuo=question.indexOf('(');
        int youkuo=question.indexOf(')');
        int lengg=question.length();
        char A='A';
        Double a;
        Double result;
        if(zuokuo!=youkuo)        //说明题目中有括号
        {
            if(zuokuo==0&&youkuo==lengg-1)  //两边
            {
                inner_question=question.substring(1,youkuo);
                a=calculate_nobracket(inner_question);
                result=a;
            }
            else if(zuokuo==0&&youkuo!=lengg-1) //左括号在最左边，右括号不在最右边
            {
                inner_question=question.substring(1,youkuo);
                a=calculate_nobracket(inner_question);
                end_question="A"+question.substring(youkuo+1);
                result=calculate_nobracket_particular(end_question,A,a);
            }
            else if(zuokuo!=0&&youkuo==lengg-1) //左括号不在最左边，右括号在最右边
            {
                inner_question=question.substring(zuokuo+1,youkuo);
                a=calculate_nobracket(inner_question);
                end_question=question.substring(0,zuokuo)+'A';
                result=calculate_nobracket_particular(end_question,A,a);
            }
            else            //括号在中间
            {
                inner_question=question.substring(zuokuo+1,youkuo);
                a=calculate_nobracket(inner_question);
                end_question=question.substring(0,zuokuo)+'A'+question.substring(youkuo+1);
                result=calculate_nobracket_particular(end_question,A,a);
            }
        }
        else //没括号
        {
            result=calculate_nobracket(question);
        }
        return result;
    }

    public static Double calculate_nobracket(String question) {
        int index = 0;
        int len = question.length();
        Stack<Double> math_stack = new Stack<Double>();
        Stack<Character> char_stack = new Stack<Character>();
        while (index <= len - 1)
        {
            if (question.charAt(index) == 's' || question.charAt(index) == 'c' || question.charAt(index) == 't')  //sin,cos,tan
            {
                index += 3;
                if (question.charAt(index - 3) == 's') {
                    switch (question.charAt(index)) {
                        case '3': {
                            math_stack.push(0.5);
                            index += 2;
                            break;
                        }
                        case '4': {
                            math_stack.push(0.705);
                            index += 2;
                            break;
                        }
                        case '6': {
                            math_stack.push(0.865);
                            index += 2;
                            break;
                        }
                        case '9': {
                            math_stack.push(1.0);
                            index += 2;
                            break;
                        }
                    }
                } else if (question.charAt(index - 3) == 'c') {
                    switch (question.charAt(index)) {
                        case '3': {
                            math_stack.push(0.865);
                            index += 2;
                            break;
                        }
                        case '4': {
                            math_stack.push(0.705);
                            index += 2;
                            break;
                        }
                        case '6': {
                            math_stack.push(0.5);
                            index += 2;
                            break;
                        }
                        case '9': {
                            math_stack.push(0.0);
                            index += 2;
                            break;
                        }
                    }
                } else if (question.charAt(index - 3) == 't') {
                    switch (question.charAt(index)) {
                        case '3': {
                            math_stack.push(0.577);
                            index += 2;
                            break;
                        }
                        case '4': {
                            math_stack.push(1.0);
                            index += 2;
                            break;
                        }
                        case '6': {
                            math_stack.push(1.730);
                            index += 2;
                            break;
                        }
                    }
                }
            }
            else if (question.charAt(index) >= '0' && question.charAt(index) <= '9')      //数字
            {
                int indexnumber = 0;
                double indexdouble = 0.0;
                Double indexDouble = 0.0;
                if (index + 1 < len && question.charAt(index + 1) >= '0' && question.charAt(index + 1) <= '9')  //两位数
                {
                    String str = question.substring(index, index + 2);
                    indexnumber = Integer.valueOf(str);
                    indexdouble = indexnumber;
                    indexDouble = indexdouble;
                    if (index + 2 < len && question.charAt(index + 2) == '½') {
                        indexDouble = Math.sqrt(indexDouble);
                        math_stack.push(indexDouble);
                        index += 3;
                    } else if (index + 2 < len && question.charAt(index + 2) == '²') {
                        indexDouble = Math.pow(indexDouble, 2);
                        math_stack.push(indexDouble);
                        index += 3;
                    } else {
                        math_stack.push(indexDouble);
                        index += 2;
                    }
                } else                     //一位数
                {
                    String str = question.substring(index, index + 1);
                    indexnumber = Integer.valueOf(str);
                    indexdouble = indexnumber;
                    indexDouble = indexdouble;
                    if (index + 1 < len && question.charAt(index + 1) == '½') {
                        indexDouble = Math.sqrt(indexDouble);
                        math_stack.push(indexDouble);
                        index += 2;
                    } else if (index + 1 < len && question.charAt(index + 1) == '²') {
                        indexDouble = Math.pow(indexDouble, 2);
                        math_stack.push(indexDouble);
                        index += 2;
                    } else {
                        math_stack.push(indexDouble);
                        index += 1;
                    }
                }
            }
            else if (question.charAt(index) == '*' || question.charAt(index) == '/')       //乘除号
            {
                Double firstnumber = math_stack.peek();
                math_stack.pop();
                Double secondnumber = 0.0;
                boolean flag = true;                 //true为乘号，false为除号；
                if (question.charAt(index) == '/') {
                    flag = false;
                }
                int indexnumber = 0;
                double indexdouble = 0.0;
                Double indexDouble = 0.0;
                if (index + 2 < len && question.charAt(index + 2) >= '0' && question.charAt(index + 2) <= '9')  //乘除号后面跟的是两位数
                {
                    String str = question.substring(index + 1, index + 3);
                    indexnumber = Integer.valueOf(str);
                    indexdouble = indexnumber;
                    indexDouble = indexdouble;
                    if (index + 3 < len && question.charAt(index + 3) == '½') {
                        indexDouble = Math.sqrt(indexDouble);
                        index += 4;
                    } else if (index + 3 < len && question.charAt(index + 3) == '²') {
                        indexDouble = Math.pow(indexDouble, 2);
                        ;
                        index += 4;
                    } else {
                        index += 3;
                    }
                    secondnumber = indexDouble;
                }
                else if(index + 1 < len && question.charAt(index + 1) >= '0' && question.charAt(index + 1) <= '9')          //乘除号后面跟的是一位数
                {
                    String str = question.substring(index + 1, index + 2);
                    indexnumber = Integer.valueOf(str);
                    indexdouble = indexnumber;
                    indexDouble = indexdouble;
                    if (index + 2 < len && question.charAt(index + 2) == '½') {
                        indexDouble = Math.sqrt(indexDouble);
                        index += 3;
                    } else if (index + 2 < len && question.charAt(index + 2) == '²') {
                        indexDouble = Math.pow(indexDouble, 2);
                        ;
                        index += 3;
                    } else {
                        index += 2;
                    }
                    secondnumber = indexDouble;
                }
                else if(index+1<len&&(question.charAt(index+1) == 's' || question.charAt(index+1) == 'c' || question.charAt(index+1) == 't'))      //乘除号后面跟的是sin,cos,tan
                {
                    index += 4;
                    if (question.charAt(index - 3) == 's') {
                        switch (question.charAt(index)) {
                            case '3': {
                                secondnumber=0.5;
                                index += 2;
                                break;
                            }
                            case '4': {
                                secondnumber=0.705;
                                index += 2;
                                break;
                            }
                            case '6': {
                                secondnumber=0.865;
                                index += 2;
                                break;
                            }
                            case '9': {
                                secondnumber=1.0;
                                index += 2;
                                break;
                            }
                        }
                    }
                    else if (question.charAt(index - 3) == 'c') {
                        switch (question.charAt(index)) {
                            case '3': {
                                secondnumber=0.865;
                                index += 2;
                                break;
                            }
                            case '4': {
                                secondnumber=0.705;
                                index += 2;
                                break;
                            }
                            case '6': {
                                secondnumber=0.5;
                                index += 2;
                                break;
                            }
                            case '9': {
                                secondnumber=0.0;
                                index += 2;
                                break;
                            }
                        }
                    } else if (question.charAt(index - 3) == 't') {
                        switch (question.charAt(index)) {
                            case '3': {
                                secondnumber=0.577;
                                index += 2;
                                break;
                            }
                            case '4': {
                                secondnumber=1.0;
                                index += 2;
                                break;
                            }
                            case '6': {
                                secondnumber=1.730;
                                index += 2;
                                break;
                            }
                        }
                    }
                }
                Double result = 0.0;
                if (flag == true) {
                    result = firstnumber * secondnumber;
                } else {
                    result = firstnumber / secondnumber;
                }
                math_stack.push(result);
            }
            else if (question.charAt(index) == '+' || question.charAt(index) == '-') {
                char_stack.push(question.charAt(index));
                index += 1;
            }
            else
            {
                System.out.println("有错误字符的输入");
                index=len-1;
            }
        }
        Stack<Double> math_stack2 = new Stack<Double>();
        Stack<Character> char_stack2 = new Stack<Character>();

        //把符号栈里的负号变为正号
        while (char_stack.empty()==false)
        {
            if(char_stack.peek()=='+')
            {
                char_stack2.push(char_stack.peek());
                char_stack.pop();
                math_stack2.push(math_stack.peek());
                math_stack.pop();
            }
            else
            {
                char_stack2.push('+');
                char_stack.pop();
                math_stack2.push(math_stack.peek()*(-1));
                math_stack.pop();
            }
        }
        while (char_stack2.empty()==false)
        {
            char_stack.push(char_stack2.peek());
            char_stack2.pop();
            math_stack.push(math_stack2.peek());
            math_stack2.pop();
        }
        //符号栈中负号变正号结束

        while (char_stack.empty() == false) {
            Double secondnumber = math_stack.peek();
            math_stack.pop();
            Double firstnumber = math_stack.peek();
            math_stack.pop();
            char operand = char_stack.peek();
            char_stack.pop();
            Double result = 0.0;
            if (operand == '+') {
                result = firstnumber + secondnumber;
                math_stack.push(result);
            } else {
                result = firstnumber - secondnumber;
                math_stack.push(result);
            }
        }
        Double result = math_stack.peek();
        math_stack.pop();
        return result;
    }

    public static Double calculate_nobracket_particular(String question, char A , Double a) {
        int index = 0;
        int len = question.length();
        Stack<Double> math_stack = new Stack<Double>();
        Stack<Character> char_stack = new Stack<Character>();
        while (index <= len - 1)
        {
            if (question.charAt(index) == 's' || question.charAt(index) == 'c' || question.charAt(index) == 't')  //sin,cos,tan
            {
                index += 3;
                if (question.charAt(index - 3) == 's') {
                    switch (question.charAt(index)) {
                        case '3': {
                            math_stack.push(0.5);
                            index += 2;
                            break;
                        }
                        case '4': {
                            math_stack.push(0.705);
                            index += 2;
                            break;
                        }
                        case '6': {
                            math_stack.push(0.865);
                            index += 2;
                            break;
                        }
                        case '9': {
                            math_stack.push(1.0);
                            index += 2;
                            break;
                        }
                    }
                } else if (question.charAt(index - 3) == 'c') {
                    switch (question.charAt(index)) {
                        case '3': {
                            math_stack.push(0.865);
                            index += 2;
                            break;
                        }
                        case '4': {
                            math_stack.push(0.705);
                            index += 2;
                            break;
                        }
                        case '6': {
                            math_stack.push(0.5);
                            index += 2;
                            break;
                        }
                        case '9': {
                            math_stack.push(0.0);
                            index += 2;
                            break;
                        }
                    }
                } else if (question.charAt(index - 3) == 't') {
                    switch (question.charAt(index)) {
                        case '3': {
                            math_stack.push(0.577);
                            index += 2;
                            break;
                        }
                        case '4': {
                            math_stack.push(1.0);
                            index += 2;
                            break;
                        }
                        case '6': {
                            math_stack.push(1.730);
                            index += 2;
                            break;
                        }
                    }
                }
            }
            else if(question.charAt(index)==A)
            {
                if(index+1<len&&question.charAt(index+1)=='½')
                {
                    a=Math.sqrt(a);
                    math_stack.push(a);
                    index+=2;
                }
                else if(index+1<len&&question.charAt(index+1)=='²')
                {
                    a=Math.pow(a,2);
                    math_stack.push(a);
                    index+=2;
                }
                else
                {
                    math_stack.push(a);
                    index+=1;
                }
            }
            else if (question.charAt(index) >= '0' && question.charAt(index) <= '9')      //数字
            {
                int indexnumber = 0;
                double indexdouble = 0.0;
                Double indexDouble = 0.0;
                if (index + 1 < len && question.charAt(index + 1) >= '0' && question.charAt(index + 1) <= '9')  //两位数
                {
                    String str = question.substring(index, index + 2);
                    indexnumber = Integer.valueOf(str);
                    indexdouble = indexnumber;
                    indexDouble = indexdouble;
                    if (index + 2 < len && question.charAt(index + 2) == '½') {
                        indexDouble = Math.sqrt(indexDouble);
                        math_stack.push(indexDouble);
                        index += 3;
                    } else if (index + 2 < len && question.charAt(index + 2) == '²') {
                        indexDouble = Math.pow(indexDouble, 2);
                        math_stack.push(indexDouble);
                        index += 3;
                    } else {
                        math_stack.push(indexDouble);
                        index += 2;
                    }
                } else                     //一位数
                {
                    String str = question.substring(index, index + 1);
                    indexnumber = Integer.valueOf(str);
                    indexdouble = indexnumber;
                    indexDouble = indexdouble;
                    if (index + 1 < len && question.charAt(index + 1) == '½') {
                        indexDouble = Math.sqrt(indexDouble);
                        math_stack.push(indexDouble);
                        index += 2;
                    } else if (index + 1 < len && question.charAt(index + 1) == '²') {
                        indexDouble = Math.pow(indexDouble, 2);
                        math_stack.push(indexDouble);
                        index += 2;
                    } else {
                        math_stack.push(indexDouble);
                        index += 1;
                    }
                }
            }
            else if (question.charAt(index) == '*' || question.charAt(index) == '/')       //乘除号
            {
                Double firstnumber = math_stack.peek();
                math_stack.pop();
                Double secondnumber = 0.0;
                boolean flag = true;                 //true为乘号，false为除号；
                if (question.charAt(index) == '/') {
                    flag = false;
                }
                int indexnumber = 0;
                double indexdouble = 0.0;
                Double indexDouble = 0.0;
                if (index + 2 < len && question.charAt(index + 2) >= '0' && question.charAt(index + 2) <= '9')  //乘除号后面跟的是两位数
                {
                    String str = question.substring(index + 1, index + 3);
                    indexnumber = Integer.valueOf(str);
                    indexdouble = indexnumber;
                    indexDouble = indexdouble;
                    if (index + 3 < len && question.charAt(index + 3) == '½') {
                        indexDouble = Math.sqrt(indexDouble);
                        index += 4;
                    } else if (index + 3 < len && question.charAt(index + 3) == '²') {
                        indexDouble = Math.pow(indexDouble, 2);
                        ;
                        index += 4;
                    } else {
                        index += 3;
                    }
                    secondnumber = indexDouble;
                }
                else if(index + 1 < len && question.charAt(index + 1) >= '0' && question.charAt(index + 1) <= '9')          //乘除号后面跟的是一位数
                {
                    String str = question.substring(index + 1, index + 2);
                    indexnumber = Integer.valueOf(str);
                    indexdouble = indexnumber;
                    indexDouble = indexdouble;
                    if (index + 2 < len && question.charAt(index + 2) == '½') {
                        indexDouble = Math.sqrt(indexDouble);
                        index += 3;
                    } else if (index + 2 < len && question.charAt(index + 2) == '²') {
                        indexDouble = Math.pow(indexDouble, 2);
                        index += 3;
                    } else {
                        index += 2;
                    }
                    secondnumber = indexDouble;
                }
                else if(index+1<len&&(question.charAt(index+1) == 's' || question.charAt(index+1) == 'c' || question.charAt(index+1) == 't'))      //乘除号后面跟的是sin,cos,tan
                {
                    index += 4;
                    if (question.charAt(index - 3) == 's') {
                        switch (question.charAt(index)) {
                            case '3': {
                                secondnumber=0.5;
                                index += 2;
                                break;
                            }
                            case '4': {
                                secondnumber=0.705;
                                index += 2;
                                break;
                            }
                            case '6': {
                                secondnumber=0.865;
                                index += 2;
                                break;
                            }
                            case '9': {
                                secondnumber=1.0;
                                index += 2;
                                break;
                            }
                        }
                    }
                    else if (question.charAt(index - 3) == 'c')
                    {
                        switch (question.charAt(index)) {
                            case '3': {
                                secondnumber=0.865;
                                index += 2;
                                break;
                            }
                            case '4': {
                                secondnumber=0.705;
                                index += 2;
                                break;
                            }
                            case '6': {
                                secondnumber=0.5;
                                index += 2;
                                break;
                            }
                            case '9': {
                                secondnumber=0.0;
                                index += 2;
                                break;
                            }
                        }
                    }
                    else if (question.charAt(index - 3) == 't')
                    {
                        switch (question.charAt(index)) {
                            case '3': {
                                secondnumber=0.577;
                                index += 2;
                                break;
                            }
                            case '4': {
                                secondnumber=1.0;
                                index += 2;
                                break;
                            }
                            case '6': {
                                secondnumber=1.730;
                                index += 2;
                                break;
                            }
                        }
                    }
                }
                else if(index+1<len&&(question.charAt(index+1) == A)) //外部传入的括号中的结果
                {
                    if (index + 2 < len && question.charAt(index + 2) == '½')
                    {
                        a = Math.sqrt(a);
                        index += 3;
                    } else if (index + 2 < len && question.charAt(index + 2) == '²')
                    {
                        a = Math.pow(a, 2);
                        index += 3;
                    }
                    else
                    {
                        index += 2;
                    }
                    secondnumber = a;
                }

                Double result = 0.0;
                if (flag == true) {
                    result = firstnumber * secondnumber;
                } else {
                    result = firstnumber / secondnumber;
                }
                math_stack.push(result);
            }
            else if (question.charAt(index) == '+' || question.charAt(index) == '-') {
                char_stack.push(question.charAt(index));
                index += 1;
            }
            else
            {
                System.out.println("有错误字符的输入");
                index=len-1;
            }
        }
        Stack<Double> math_stack2 = new Stack<Double>();
        Stack<Character> char_stack2 = new Stack<Character>();

        //把符号栈里的负号变为正号
        while (char_stack.empty()==false)
        {
            if(char_stack.peek()=='+')
            {
                char_stack2.push(char_stack.peek());
                char_stack.pop();
                math_stack2.push(math_stack.peek());
                math_stack.pop();
            }
            else
            {
                char_stack2.push('+');
                char_stack.pop();
                math_stack2.push(math_stack.peek()*(-1));
                math_stack.pop();
            }
        }
        while (char_stack2.empty()==false)
        {
            char_stack.push(char_stack2.peek());
            char_stack2.pop();
            math_stack.push(math_stack2.peek());
            math_stack2.pop();
        }
        //符号栈中负号变正号结束

        while (char_stack.empty() == false)
        {
            Double secondnumber = math_stack.peek();
            math_stack.pop();
            Double firstnumber = math_stack.peek();
            math_stack.pop();
            char operand = char_stack.peek();
            char_stack.pop();
            Double result = 0.0;
            if (operand == '+') {
                result = firstnumber + secondnumber;
                math_stack.push(result);
            } else {
                result = firstnumber - secondnumber;
                math_stack.push(result);
            }
        }
        Double result = math_stack.peek();
        math_stack.pop();
        return result;
    }

    public static Boolean userlogin(String account,String password) throws Exception         //登陆
    {
        String address = "信息\\";
        File file = new File(address);
        file.mkdirs();//生成文件夹
        address=address+"information.txt";
        file = new File(address);
        if(!file.exists())
        {
            file.createNewFile(); // 创建新文件,有同名的文件的话直接覆盖
        }
        if(checkinformation(account,password))    //如果为真，则数据库中有这个账号，登陆成功
        {
            return true;        //登陆成功返回true
        }
        else
        {
            return false;       //登录失败返回false
        }
    }
    public static Boolean checkinformation(String account,String password) throws Exception  //查找文件中是否有该账号且密码对应
    {
        String path="信息\\information.txt";
        File file = new File(path);
        if(file.isFile())
        {
            InputStreamReader reader = new InputStreamReader(new FileInputStream(file));
            BufferedReader br = new BufferedReader(reader);
            String line="";
            while ((line = br.readLine()) != null)
            {
                if(line.equals(account+" "+password))
                {
                    return true;
                }
            }
            br.close();
        }
        return false;
    }
    public static Boolean resister(String account,String password) throws Exception       //注册
    {
        String address = "信息\\";
        File file = new File(address);
        file.mkdirs();//生成文件夹
        address=address+"information.txt";
        file = new File(address);
        if(!file.exists())
        {
            file.createNewFile(); // 创建新文件,有同名的文件的话直接覆盖
        }
        FileOutputStream fos = new FileOutputStream(file,true);
        OutputStreamWriter osw = new OutputStreamWriter(fos);
        BufferedWriter bw = new BufferedWriter(osw);
        if(checkaccount(account))    //如果为真，则数据库中有这个账号，注册失败
        {
            return false;
        }
        else                                        //为假，数据库中无此账号，注册成功
        {
            bw.write(account+" "+password);
            bw.newLine();
            bw.flush();
            return true;
        }
    }

    public static Boolean checkaccount(String account)throws Exception //查找账户是否已存在
    {
        String path="信息\\information.txt";
        File file = new File(path);
        if(file.isFile())
        {
            InputStreamReader reader = new InputStreamReader(new FileInputStream(file));
            BufferedReader br = new BufferedReader(reader);
            String line="";
            while ((line = br.readLine()) != null)
            {
                String[] str=line.split("\\s+");
                if(str[0].equals(account))
                {
                    return true;
                }
            }
            br.close();
        }
        return false;
    }

    //修改密码
    public static Boolean changepassword(String account,String password,String newpassword)
    {
        Boolean flag=false;
        try
        {
            BufferedReader bufReader =
                    new BufferedReader(
                            new InputStreamReader(
                                    new FileInputStream(
                                            new File("信息\\information.txt"))));

            StringBuffer strBuf = new StringBuffer();
            String bechange=account+" "+password;
            String changed=account+" "+newpassword;
            for (String tmp = null; (tmp = bufReader.readLine()) != null; tmp = null) {
                // 在这里做替换操作
                if(tmp.equals(bechange))
                {
                    flag=true;
                }
                tmp = tmp.replaceAll(bechange, changed);
                strBuf.append(tmp);
                strBuf.append(System.getProperty("line.separator"));
            }
            bufReader.close();

            PrintWriter printWriter = new PrintWriter("信息\\information.txt");
            printWriter.write(strBuf.toString().toCharArray());
            printWriter.flush();
            printWriter.close();
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
        return flag;
    }

}

